# -*- coding: utf-8 -*-

import web

class Home:
    def GET(self):
        return 'hello world'