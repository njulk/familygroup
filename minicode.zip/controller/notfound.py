# -*- coding: utf-8 -*-

import web

def notfound():
    return web.notfound('Sorry, the page you were looking for was not found.')